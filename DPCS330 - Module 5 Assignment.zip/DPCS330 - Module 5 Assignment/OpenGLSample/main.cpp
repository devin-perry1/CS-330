#include <iostream>         
#include <cstdlib>         
#include <GL/glew.h>        
#include <GLFW/glfw3.h>     
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>      // Image loading Utility functions

using namespace std;

#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

namespace
{
    // Name of window and dimensions
    const char* const WINDOW_TITLE = "Module 5 Assignment - Devin Perry"; 

    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;

    struct GLMesh
    {
        GLuint vao;         
        GLuint vbos[2];     
        GLuint nIndices;    
    };

    GLFWwindow* gWindow = nullptr;
    GLMesh gMesh;
    /// ///////////////////// 
    GLuint gTextureIdHappy;
    GLuint gTextureIdHat;
    bool gIsHatOn = true;
    GLuint gProgramId;

    // Initial Camera Parameters
    glm::vec3 cameraPosition = glm::vec3(0.0f, 0.0f, 5.0f);
    glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
    glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
    float cameraSpeed = 0.1f;
    float cameraRotationSpeed = 0.5f;
    float cameraZoomSpeed = 0.1f;
    double lastX = WINDOW_WIDTH / 2.0;
    double lastY = WINDOW_HEIGHT / 2.0;
}

// Initializers for everything
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UCreateMesh(GLMesh& mesh);
void UDestroyMesh(GLMesh& mesh);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);
void ProcessKeyboardInput(GLFWwindow* window);
void ProcessMouseInput(GLFWwindow* window, double xpos, double ypos);
void ProcessScrollInput(GLFWwindow* window, double xoffset, double yoffset);

/* Vertex Shader Source Code*/
const GLchar* vertexShaderSource = GLSL(440,
    layout(location = 0) in vec3 position;
layout(location = 2) in vec2 textureCoordinate;

out vec2 vertexTextureCoordinate;

void main()
{
    gl_Position = vec4(position.x, position.y, position.z, 1.0);
    vertexTextureCoordinate = textureCoordinate;
}
);

/* Fragment Shader Source Code*/
const GLchar* fragmentShaderSource = GLSL(440,
    in vec2 vertexTextureCoordinate;

out vec4 fragmentColor;

uniform sampler2D uTextureBase;
uniform sampler2D uTextureExtra;
uniform bool multipleTextures;

void main()
{
    fragmentColor = texture(uTextureBase, vertexTextureCoordinate);
    if (multipleTextures)
    {
        vec4 extraTexture = texture(uTextureExtra, vertexTextureCoordinate);
        if (extraTexture.a != 0.0)
            fragmentColor = extraTexture;
    }
}
);

void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}

int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    UCreateMesh(gMesh); 

    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
        return EXIT_FAILURE;

    //////////////////////////////
    const char* texFilename = "../../resources/textures/smiley.png";
    if (!UCreateTexture(texFilename, gTextureIdHappy))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    texFilename = "../../resources/textures/bandana.png";
    if (!UCreateTexture(texFilename, gTextureIdHat))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }

    glUseProgram(gProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gProgramId, "uTextureBase"), 0);
    // We set the texture as texture unit 1
    glUniform1i(glGetUniformLocation(gProgramId, "uTextureExtra"), 1);

    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    // Cursor caller
    glfwSetCursorPosCallback(gWindow, [](GLFWwindow* window, double xpos, double ypos) {
        ProcessMouseInput(window, xpos, ypos);
        });
    
    // Scroll caller
    glfwSetScrollCallback(gWindow, [](GLFWwindow* window, double xoffset, double yoffset) {
        ProcessScrollInput(window, xoffset, yoffset);
        });

    while (!glfwWindowShouldClose(gWindow))
    {
        UProcessInput(gWindow);
        ProcessKeyboardInput(gWindow);
        URender();
        glfwPollEvents();
    }
    
    UDestroyMesh(gMesh);

    UDestroyTexture(gTextureIdHappy);
    UDestroyTexture(gTextureIdHat);

    UDestroyShaderProgram(gProgramId);

    exit(EXIT_SUCCESS); 
}

bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);

    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);

    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}

void UProcessInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);
    if (glfwGetKey(window, GLFW_KEY_H) == GLFW_PRESS && !gIsHatOn)
        gIsHatOn = true;
    else if (glfwGetKey(window, GLFW_KEY_J) == GLFW_PRESS && gIsHatOn)
        gIsHatOn = false;
}

void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}

void URender()
{
    glEnable(GL_DEPTH_TEST);

    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

 // Scales the object by 4 to enlarge 
    glm::mat4 scale = glm::scale(glm::vec3(2.0f, 2.0f, 2.0f));
    
 // Rotates shape 
    glm::mat4 rotation = glm::rotate(45.0f, glm::vec3(0.0f, 1.0f, 0.0f));
    
 // Placing the object in the center of screen
    glm::mat4 translation = glm::translate(glm::vec3(-1.0f, -1.0f, 0.0f));

    glm::mat4 model = translation * rotation * scale;

    // Changing the view to be look at 
    glm::mat4 view = glm::lookAt(cameraPosition, cameraPosition + cameraFront, cameraUp);

    glm::mat4 projection = glm::perspective(glm::radians(45.0f), (float)WINDOW_WIDTH / (float)WINDOW_HEIGHT, 0.1f, 100.0f);

    glUseProgram(gProgramId);

    GLint modelLoc = glGetUniformLocation(gProgramId, "model");
    GLint viewLoc = glGetUniformLocation(gProgramId, "view");
    GLint projLoc = glGetUniformLocation(gProgramId, "projection");

    GLuint multipleTexturesLoc = glGetUniformLocation(gProgramId, "multipleTextures");
    glUniform1i(multipleTexturesLoc, gIsHatOn);

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    glBindVertexArray(gMesh.vao);

    //////////////////////////////////////////
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureIdHappy);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, gTextureIdHat);

    glDrawElements(GL_TRIANGLES, gMesh.nIndices, GL_UNSIGNED_SHORT, NULL); 

    glBindVertexArray(0);

    glfwSwapBuffers(gWindow);    
}


// Implements the UCreateMesh function
void UCreateMesh(GLMesh& mesh)
{
    // Position and color data. Notice that the tip ones marked in my notes 
    // by *** all have the same coordinates, as they meet at the same spot.
    GLfloat verts[] = {         
         0.0f,  1.0f, -0.5f,   1.0f, 0.0f, 0.0f, 1.0f, // ***Top Right Triangle Tip Vertex
         0.5f, -0.5f, 0.0f,   0.0f, 1.0f, 0.0f, 1.0f,  //    East Bottom Vertex
        -0.5f, -0.5f, 0.0f,   0.0f, 0.0f, 1.0f, 1.0f,  //    South Bottom Vertex 
         0.0f,  1.0f, -0.5f,   1.0f, 0.0f, 1.0f, 1.0f, // ***Bottom Right Triangle Tip Vertex

         0.5f, -0.5f, -1.0f,  0.5f, 0.5f, 1.0f, 1.0f, //     North Bottom Vertex
         0.0f,  1.0f, -0.5f,  1.0f, 1.0f, 0.5f, 1.0f, //  ***Top Left Triangle Tip Vertex
         0.0f,  1.0f, -0.5f,  0.2f, 0.2f, 0.5f, 1.0f, //  ***Bottom Left Triangle Tip Vertex
        -0.5f, -0.5f, -1.0f,  1.0f, 0.0f, 1.0f, 1.0f  //     West Bottom Vertex
    };

    // Some markers here that helped me make the pyramid
    GLushort indices[] = {
        1, 2, 3,   // Triangle 1 Front Right
        0, 1, 4,  // Triangle 2 Back Right      
        4, 5, 7, // Triangle 3 Back Left
        2, 6, 7, // Triangle 4 Front Left
        1, 4, 7, // Triangle 5 Bottom 1
        1, 2, 7 // Triangle 6 Bottom 2
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerColor = 4;
    const GLuint floatsPerUV = 2;

    glGenVertexArrays(1, &mesh.vao); 
    glBindVertexArray(mesh.vao);

    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); 
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); 

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerColor);

    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerColor, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerColor)));
    glEnableVertexAttribArray(2);
}

void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(2, mesh.vbos);
}

/*Generate and load the texture*/
bool UCreateTexture(const char* filename, GLuint& textureId)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        return true;
    }

    // Error loading the image
    return false;
}

void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}

bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    int success = 0;
    char infoLog[512];

    programId = glCreateProgram();

    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    glCompileShader(vertexShaderId); 

    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); 
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);  
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);   

    return true;
}

void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
    glfwTerminate(); 
}

// Keyboard input handler for movement actions
void ProcessKeyboardInput(GLFWwindow* window) {
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)  // W
        cameraPosition += cameraSpeed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)  // A
        cameraPosition -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)  // S
        cameraPosition -= cameraSpeed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)  // D
        cameraPosition += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)  // Q
        cameraPosition -= cameraSpeed * cameraUp;
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)  // E
        cameraPosition += cameraSpeed * cameraUp;
}

// Mouse input handler to handle looking around
void ProcessMouseInput(GLFWwindow* window, double xpos, double ypos) {
    static double lastX = WINDOW_WIDTH / 2.0;
    static double lastY = WINDOW_HEIGHT / 2.0;

    double xoffset = xpos - lastX;
    double yoffset = lastY - ypos;

    lastX = xpos;
    lastY = ypos;

    const float sensitivity = 0.05f;
    xoffset *= sensitivity;
    yoffset *= sensitivity;

    cameraFront = glm::normalize(glm::rotate(glm::mat4(1.0f), glm::radians((float)xoffset), cameraUp) * glm::vec4(cameraFront, 0.0f));
    glm::vec3 right = glm::normalize(glm::cross(cameraFront, cameraUp));
    cameraFront = glm::normalize(glm::rotate(glm::mat4(1.0f), glm::radians((float)yoffset), right) * glm::vec4(cameraFront, 0.0f));
    cameraRotationSpeed = sensitivity * 10.0f;
}

// Scroll input handler that accelerates movement actions
void ProcessScrollInput(GLFWwindow* window, double xoffset, double yoffset)
{
    cameraSpeed += static_cast<float>(yoffset) * 0.1f;
    cameraSpeed = glm::clamp(cameraSpeed, 0.1f, 10.0f);
}